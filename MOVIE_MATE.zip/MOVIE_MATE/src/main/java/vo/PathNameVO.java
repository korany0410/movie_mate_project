package vo;

public class PathNameVO {
	private String pathname;

	public String getPathname() {
		return pathname;
	}

	public void setPathname(String pathname) {
		this.pathname = pathname;
	}

}
