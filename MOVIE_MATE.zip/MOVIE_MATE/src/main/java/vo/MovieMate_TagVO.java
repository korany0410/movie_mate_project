package vo;

public class MovieMate_TagVO {
	private int tag_idx;
	private String tag_name;

	public int getTag_idx() {
		return tag_idx;
	}

	public void setTag_idx(int tag_idx) {
		this.tag_idx = tag_idx;
	}

	public String getTag_name() {
		return tag_name;
	}

	public void setTag_name(String tag_name) {
		this.tag_name = tag_name;
	}

}
