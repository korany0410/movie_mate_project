package vo;

public class Movie_TagVO {
	private int movie_idx, tag_idx;

	public int getMovie_idx() {
		return movie_idx;
	}

	public void setMovie_idx(int movie_idx) {
		this.movie_idx = movie_idx;
	}

	public int getTag_idx() {
		return tag_idx;
	}

	public void setTag_idx(int tag_idx) {
		this.tag_idx = tag_idx;
	}
}
