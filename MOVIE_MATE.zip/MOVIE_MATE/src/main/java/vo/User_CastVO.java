package vo;

public class User_CastVO {
	private int user_idx, cast_idx;
	private String isUp;

	public int getUser_idx() {
		return user_idx;
	}

	public void setUser_idx(int user_idx) {
		this.user_idx = user_idx;
	}

	public int getCast_idx() {
		return cast_idx;
	}

	public void setCast_idx(int cast_idx) {
		this.cast_idx = cast_idx;
	}

	public String getIsUp() {
		return isUp;
	}

	public void setIsUp(String isUp) {
		this.isUp = isUp;
	}

}
