package vo;

public class Movie_CastVO {
	private int movie_idx, cast_idx;

	public int getMovie_idx() {
		return movie_idx;
	}

	public void setMovie_idx(int movie_idx) {
		this.movie_idx = movie_idx;
	}

	public int getCast_idx() {
		return cast_idx;
	}

	public void setCast_idx(int cast_idx) {
		this.cast_idx = cast_idx;
	}

}
