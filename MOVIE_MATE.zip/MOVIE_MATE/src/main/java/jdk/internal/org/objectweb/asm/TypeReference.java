package jdk.internal.org.objectweb.asm;

public class TypeReference {

}
